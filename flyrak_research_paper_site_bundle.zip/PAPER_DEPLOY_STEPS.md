# Paper deployment steps

1. Copy the bundle contents into the root of `Dania-Yasir/flyrak-project`.
2. Confirm the final manuscript is at `work/research_paper.md`.
3. Confirm the site files are at `work/paper/`.
4. Confirm `.github/workflows/paper-pages.yml` exists.
5. Commit and push to `main`.
6. In GitHub: **Settings → Pages → Build and deployment → Source → GitHub Actions**.
7. Open the **Actions** tab and confirm `Deploy research paper to Pages` completes successfully. If Pages was enabled after the first workflow run, rerun the workflow once.
8. Open the deployed URL and check the figures, notebook links, mobile layout, and references.
9. Only after the live page is verified, replace the placeholder in `submission/paper_url.txt` with the single direct deployed paper URL and nothing else.

Expected project-site URL format after Pages is enabled:

`https://dania-yasir.github.io/flyrak-project/`

Do not put this URL into `submission/paper_url.txt` until the live deployment is confirmed.
